import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';

import routes from './routes/index.js';
import { errorMiddleware } from './middleware/index.js';
import logger from './utils/logger.js';

const app = express();

process.on('uncaughtException', (error) => {
  logger.error('Uncaught exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled rejection at:', promise, 'reason:', reason);
});

process.on('SIGINT', async () => {
  logger.info('Interrupted');
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('SIGTERM signal received');
  await new Promise(resolve => setTimeout(resolve, 3000));
  logger.info('Exiting');
  process.exit();
});

app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN,
  credentials: true,
}));
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============================================================================
// DIAGNOSTIC LOGGING ON STARTUP
// ============================================================================
logger.info('\n========== API SERVER STARTUP ==========' );
logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
logger.info(`Port: ${process.env.PORT || 3001}`);
logger.info(`CORS Origin: ${process.env.CORS_ORIGIN}`);
logger.info(`API Base URL: ${process.env.API_BASE_URL}`);

// Log PagSeguro credentials status
const accessToken = (process.env.PAGSEGURO_ACCESS_TOKEN || '').trim();
const publicKey = (process.env.PAGSEGURO_PUBLIC_KEY || '').trim();

logger.info('\n--- PagSeguro Credentials Status ---');
if (accessToken) {
  logger.info(`✓ PAGSEGURO_ACCESS_TOKEN loaded: ${accessToken.substring(0, 10)}...`);
} else {
  logger.warn('⚠ WARNING: PAGSEGURO_ACCESS_TOKEN is missing from .env');
}

if (publicKey) {
  logger.info(`✓ PAGSEGURO_PUBLIC_KEY loaded: ${publicKey.substring(0, 10)}...`);
} else {
  logger.warn('⚠ WARNING: PAGSEGURO_PUBLIC_KEY is missing from .env');
}

logger.info('\n--- Route Registration ---');
logger.info('✓ PagSeguro routes registered at /pagseguro');
logger.info('  - POST /pagseguro/create-order');
logger.info('  - POST /pagseguro/webhook');
logger.info('\n========== STARTUP COMPLETE ==========\n');

app.use('/', routes());

app.use(errorMiddleware);

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

const port = process.env.PORT || 3001;

app.listen(port, () => {
  logger.info(`🚀 API Server running on http://localhost:${port}`);
});

export default app;
