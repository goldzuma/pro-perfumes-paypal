
import 'dotenv/config';
import express from 'express';
import paypal from 'paypal-rest-sdk';
import logger from '../utils/logger.js';

const router = express.Router();

// ============================================================================
// INITIALIZATION & VALIDATION
// ============================================================================

logger.info('\n========== PAYPAL MODULE INITIALIZATION ==========');

const clientId = (process.env.PAYPAL_CLIENT_ID || '').trim();
const clientSecret = (process.env.PAYPAL_CLIENT_SECRET || '').trim();
const paypalMode = (process.env.PAYPAL_MODE || 'sandbox').trim();

logger.info('Loading credentials from .env file...');
logger.info(`✓ PAYPAL_CLIENT_ID loaded: ${!!clientId}`);
if (clientId) {
  logger.info(`  - Length: ${clientId.length} characters`);
  logger.info(`  - Preview: ${clientId.substring(0, 30)}...`);
}
logger.info(`✓ PAYPAL_CLIENT_SECRET loaded: ${!!clientSecret}`);
if (clientSecret) {
  logger.info(`  - Length: ${clientSecret.length} characters`);
  logger.info(`  - Preview: ${clientSecret.substring(0, 30)}...`);
}
logger.info(`✓ PAYPAL_MODE loaded: ${paypalMode}`);

if (!clientId) {
  logger.error('❌ CRITICAL: PAYPAL_CLIENT_ID is not set or empty in .env');
  throw new Error('PAYPAL_CLIENT_ID not configured in .env');
}

if (!clientSecret) {
  logger.error('❌ CRITICAL: PAYPAL_CLIENT_SECRET is not set or empty in .env');
  throw new Error('PAYPAL_CLIENT_SECRET not configured in .env');
}

// ============================================================================
// VALIDATE PAYPAL MODE
// ============================================================================
if (paypalMode !== 'live' && paypalMode !== 'sandbox') {
  logger.error(`❌ CRITICAL: PAYPAL_MODE must be 'live' or 'sandbox', got: ${paypalMode}`);
  throw new Error(`Invalid PAYPAL_MODE: ${paypalMode}. Must be 'live' or 'sandbox'.`);
}

if (paypalMode === 'live') {
  logger.warn('\n⚠️  WARNING: PayPal is configured in PRODUCTION MODE (live)');
  logger.warn('   - API calls will use REAL PayPal production environment');
  logger.warn('   - Transactions will be REAL and will charge actual payment methods');
  logger.warn('   - Ensure credentials are valid production credentials');
  logger.warn('   - Ensure all URLs are HTTPS and production-ready');
} else {
  logger.info('\n✓ PayPal is configured in SANDBOX MODE (testing)');
  logger.info('   - API calls will use PayPal sandbox environment');
  logger.info('   - Transactions are simulated and will NOT charge payment methods');
}

try {
  logger.info('\nConfiguring PayPal SDK...');
  paypal.configure({
    mode: paypalMode,
    client_id: clientId,
    client_secret: clientSecret,
  });
  logger.info('✓ PayPal SDK configured successfully');
  logger.info(`  - Mode: ${paypalMode}`);
  logger.info(`  - Client ID: ${clientId.substring(0, 20)}...`);
  logger.info(`  - Client Secret: ${clientSecret.substring(0, 20)}...`);
  logger.info(`  - Configuration object created: ${typeof paypal === 'object' && paypal !== null}`);
  logger.info(`  - payment.create method available: ${typeof paypal.payment === 'object' && typeof paypal.payment.create === 'function'}`);
  logger.info(`  - payment.execute method available: ${typeof paypal.payment === 'object' && typeof paypal.payment.execute === 'function'}`);
  logger.info('\n✓✓✓ PayPal module fully initialized successfully');
  logger.info('========== INITIALIZATION COMPLETE ==========\n');
} catch (error) {
  logger.error('\n❌ CRITICAL: Failed to initialize PayPal SDK');
  logger.error(`Error message: ${error.message}`);
  logger.error(`Error stack: ${error.stack}`);
  throw new Error(`PayPal initialization failed: ${error.message}`);
}

// ============================================================================
// HELPER: Create timeout promise
// ============================================================================
function createTimeoutPromise(ms) {
  return new Promise((_, reject) => {
    setTimeout(() => {
      reject(new Error(`PayPal API call timeout after ${ms}ms`));
    }, ms);
  });
}

// ============================================================================
// POST /paypal/create-order
// Creates a PayPal order and returns the approval URL
// Request body: { items, amount, currency, returnUrl, cancelUrl }
// Response: { success: true, token: string } or { success: false, error: string }
// ============================================================================

router.post('/create-order', async (req, res) => {
  logger.info('\n========== CREATE ORDER REQUEST ==========');
  logger.info(`Timestamp: ${new Date().toISOString()}`);
  logger.info(`Request method: ${req.method}`);
  logger.info(`Request path: ${req.path}`);
  logger.info(`PayPal Mode: ${paypalMode}`);

  // ========== LOG INCOMING REQUEST ==========
  logger.info('\n--- STEP 1: LOG INCOMING REQUEST BODY ---');
  logger.info(`Raw request body: ${JSON.stringify(req.body, null, 2)}`);

  const { items, amount, currency, returnUrl, cancelUrl } = req.body;

  logger.info('Extracted parameters:');
  logger.info(`  - items: ${JSON.stringify(items)}`);
  logger.info(`  - items type: ${typeof items}`);
  logger.info(`  - items is array: ${Array.isArray(items)}`);
  if (Array.isArray(items)) {
    logger.info(`  - items length: ${items.length}`);
    items.forEach((item, idx) => {
      logger.info(`    Item ${idx + 1}:`);
      logger.info(`      - name: ${item.name}`);
      logger.info(`      - description: ${item.description}`);
      logger.info(`      - quantity: ${item.quantity}`);
      logger.info(`      - price: ${item.price}`);
    });
  }
  logger.info(`  - amount: ${amount}`);
  logger.info(`  - currency: ${currency}`);
  logger.info(`  - returnUrl: ${returnUrl}`);
  logger.info(`  - cancelUrl: ${cancelUrl}`);

  // ========== VALIDATE SDK INITIALIZATION ==========
  logger.info('\n--- STEP 2: VALIDATE SDK INITIALIZATION ---');
  logger.info('Checking if PayPal SDK is properly initialized...');
  logger.info(`  - paypal object exists: ${typeof paypal === 'object' && paypal !== null}`);
  logger.info(`  - paypal.payment exists: ${typeof paypal.payment === 'object' && paypal.payment !== null}`);
  logger.info(`  - paypal.payment.create is function: ${typeof paypal.payment === 'object' && typeof paypal.payment.create === 'function'}`);

  if (!paypal || typeof paypal !== 'object') {
    logger.error('❌ PayPal SDK is not initialized');
    const errorMsg = 'PayPal SDK not initialized';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  if (!paypal.payment || typeof paypal.payment !== 'object') {
    logger.error('❌ PayPal payment module is not initialized');
    const errorMsg = 'PayPal payment module not initialized';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  if (typeof paypal.payment.create !== 'function') {
    logger.error('❌ PayPal payment.create method is not available');
    const errorMsg = 'PayPal payment.create method not available';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  logger.info('✓ SDK initialization validation passed');

  // ========== VALIDATE CREDENTIALS ==========
  logger.info('\n--- STEP 3: VALIDATE CREDENTIALS ---');
  logger.info(`Checking if CLIENT_ID is loaded from .env...`);
  logger.info(`  - process.env.PAYPAL_CLIENT_ID exists: ${!!process.env.PAYPAL_CLIENT_ID}`);
  logger.info(`  - process.env.PAYPAL_CLIENT_ID length: ${(process.env.PAYPAL_CLIENT_ID || '').length}`);
  logger.info(`  - process.env.PAYPAL_CLIENT_ID preview: ${(process.env.PAYPAL_CLIENT_ID || '').substring(0, 30)}...`);
  logger.info(`  - process.env.PAYPAL_MODE: ${process.env.PAYPAL_MODE}`);

  if (!process.env.PAYPAL_CLIENT_ID || !process.env.PAYPAL_CLIENT_ID.trim()) {
    logger.error('❌ PAYPAL_CLIENT_ID is undefined or empty');
    const errorMsg = 'PAYPAL_CLIENT_ID not configured in .env';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }
  logger.info('✓ CLIENT_ID validation passed');

  // ========== VALIDATE REQUEST DATA ==========
  logger.info('\n--- STEP 4: VALIDATE REQUEST DATA ---');

  // Validate items array
  logger.info('Validating items parameter...');
  if (!items) {
    logger.warn('❌ Validation failed: items is undefined or null');
    return res.status(400).json({
      success: false,
      error: 'Items array is required',
      received: { items },
    });
  }

  if (!Array.isArray(items)) {
    logger.warn(`❌ Validation failed: items is not an array, received type: ${typeof items}`);
    return res.status(400).json({
      success: false,
      error: 'Items must be an array',
      received: { items, type: typeof items },
    });
  }

  if (items.length === 0) {
    logger.warn('❌ Validation failed: items array is empty');
    return res.status(400).json({
      success: false,
      error: 'Items array must not be empty',
      received: { items },
    });
  }
  logger.info(`✓ Items array validation passed: ${items.length} item(s)`);

  // Validate each item
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    logger.info(`  Item ${i + 1}:`);
    logger.info(`    - name: ${item.name}`);
    logger.info(`    - description: ${item.description}`);
    logger.info(`    - quantity: ${item.quantity}`);
    logger.info(`    - price: ${item.price}`);

    if (!item.name) {
      logger.warn(`❌ Item ${i + 1} missing name`);
      return res.status(400).json({
        success: false,
        error: `Item ${i + 1} is missing required field: name`,
      });
    }

    if (!item.description) {
      logger.warn(`❌ Item ${i + 1} missing description`);
      return res.status(400).json({
        success: false,
        error: `Item ${i + 1} is missing required field: description`,
      });
    }

    if (typeof item.quantity !== 'number' || item.quantity <= 0) {
      logger.warn(`❌ Item ${i + 1} has invalid quantity: ${item.quantity}`);
      return res.status(400).json({
        success: false,
        error: `Item ${i + 1} quantity must be a positive number`,
      });
    }

    if (typeof item.price !== 'number' || item.price < 0) {
      logger.warn(`❌ Item ${i + 1} has invalid price: ${item.price}`);
      return res.status(400).json({
        success: false,
        error: `Item ${i + 1} price must be a non-negative number`,
      });
    }
  }
  logger.info('✓ All items validation passed');

  // Validate amount
  if (typeof amount !== 'number' || amount <= 0) {
    logger.warn(`❌ Validation failed: invalid amount: ${amount}`);
    return res.status(400).json({
      success: false,
      error: 'Amount must be a positive number',
      received: { amount },
    });
  }
  logger.info(`✓ Amount validation passed: ${amount}`);

  // Validate currency
  if (!currency || typeof currency !== 'string' || currency.trim().length === 0) {
    logger.warn(`❌ Validation failed: invalid currency`);
    return res.status(400).json({
      success: false,
      error: 'Currency is required and must be a non-empty string',
      received: { currency },
    });
  }
  logger.info(`✓ Currency validation passed: ${currency}`);

  // Validate return URL
  if (!returnUrl || typeof returnUrl !== 'string') {
    logger.warn(`❌ Validation failed: invalid return URL`);
    return res.status(400).json({
      success: false,
      error: 'Valid return URL is required',
    });
  }
  logger.info(`✓ Return URL validation passed: ${returnUrl}`);

  // Validate cancel URL
  if (!cancelUrl || typeof cancelUrl !== 'string') {
    logger.warn(`❌ Validation failed: invalid cancel URL`);
    return res.status(400).json({
      success: false,
      error: 'Valid cancel URL is required',
    });
  }
  logger.info(`✓ Cancel URL validation passed: ${cancelUrl}`);

  logger.info('✓✓✓ All request data validations passed');

  // ========== FORMAT ITEMS FOR PAYPAL ==========
  logger.info('\n--- STEP 5: FORMAT ITEMS FOR PAYPAL API ---');
  const formattedItems = items.map((item, index) => {
    const formatted = {
      name: item.name,
      description: item.description,
      quantity: item.quantity.toString(),
      price: item.price.toString(),
    };
    logger.info(`  Item ${index + 1} formatted: ${JSON.stringify(formatted)}`);
    return formatted;
  });
  logger.info('✓ All items formatted successfully');

  // ========== CALCULATE TOTALS ==========
  logger.info('\n--- STEP 6: CALCULATE TOTALS ---');
  const itemTotal = formattedItems.reduce((sum, item) => sum + (parseFloat(item.price) * parseInt(item.quantity)), 0);
  const taxAmount = 0;
  const totalAmount = itemTotal + taxAmount;
  logger.info(`Item total: ${itemTotal}`);
  logger.info(`Tax amount: ${taxAmount}`);
  logger.info(`Total amount: ${totalAmount}`);

  // ========== BUILD PAYPAL PAYMENT OBJECT ==========
  logger.info('\n--- STEP 7: BUILD PAYPAL PAYMENT OBJECT ---');
  const paypalPaymentData = {
    intent: 'sale',
    payer: {
      payment_method: 'paypal',
    },
    redirect_urls: {
      return_url: returnUrl,
      cancel_url: cancelUrl,
    },
    transactions: [
      {
        amount: {
          total: totalAmount.toString(),
          currency: currency.toUpperCase(),
          details: {
            subtotal: itemTotal.toString(),
            tax: taxAmount.toString(),
          },
        },
        description: `Payment for ${items.length} item(s)`,
        item_list: {
          items: formattedItems,
        },
      },
    ],
  };

  logger.info('PayPal payment object structure:');
  logger.info(`  - Intent: ${paypalPaymentData.intent}`);
  logger.info(`  - Payer method: ${paypalPaymentData.payer.payment_method}`);
  logger.info(`  - Return URL: ${paypalPaymentData.redirect_urls.return_url}`);
  logger.info(`  - Cancel URL: ${paypalPaymentData.redirect_urls.cancel_url}`);
  logger.info(`  - Total amount: ${paypalPaymentData.transactions[0].amount.total}`);
  logger.info(`  - Currency: ${paypalPaymentData.transactions[0].amount.currency}`);
  logger.info(`  - Subtotal: ${paypalPaymentData.transactions[0].amount.details.subtotal}`);
  logger.info(`  - Tax: ${paypalPaymentData.transactions[0].amount.details.tax}`);
  logger.info(`  - Items count: ${paypalPaymentData.transactions[0].item_list.items.length}`);
  logger.info(`\nFull payment object being sent to PayPal API:`);
  logger.info(`${JSON.stringify(paypalPaymentData, null, 2)}`);

  // ========== CALL PAYPAL API WITH TIMEOUT ==========
  logger.info('\n--- STEP 8: CALL PAYPAL API WITH TIMEOUT ---');
  logger.info(`Using client ID: ${process.env.PAYPAL_CLIENT_ID.substring(0, 20)}...`);
  logger.info(`Client ID length: ${process.env.PAYPAL_CLIENT_ID.length}`);
  logger.info(`Using mode: ${process.env.PAYPAL_MODE}`);
  if (paypalMode === 'live') {
    logger.warn('⚠️  PRODUCTION MODE: Calling PayPal LIVE API (api.paypal.com)');
  } else {
    logger.info('Calling PayPal SANDBOX API (sandbox.paypal.com)');
  }
  logger.info('Calling paypal.payment.create() method with 10s timeout...');

  let paypalPayment;
  const paypalPromise = new Promise((resolve, reject) => {
    logger.info('PayPal promise created, calling payment.create()...');
    paypal.payment.create(paypalPaymentData, (error, payment) => {
      logger.info('PayPal callback invoked');
      if (error) {
        logger.error('\n❌ PAYPAL API CALLBACK ERROR');
        logger.error(`Error message: ${error.message}`);
        logger.error(`Error name: ${error.name}`);
        logger.error(`Error code: ${error.code}`);
        logger.error(`Error status: ${error.status}`);
        logger.error(`Error statusCode: ${error.statusCode}`);
        logger.error(`Full error object: ${JSON.stringify(error, null, 2)}`);

        // Log error response details if available
        if (error.response) {
          logger.error(`\nError response details:`);
          logger.error(`  - Status: ${error.response.status}`);
          logger.error(`  - Status text: ${error.response.statusText}`);
          logger.error(`  - Headers: ${JSON.stringify(error.response.headers)}`);
          logger.error(`  - Data: ${JSON.stringify(error.response.data)}`);
          logger.error(`  - Full response: ${JSON.stringify(error.response, null, 2)}`);
        }

        // Log error request details if available
        if (error.request) {
          logger.error(`\nError request details:`);
          logger.error(`  - Method: ${error.request.method}`);
          logger.error(`  - URL: ${error.request.url}`);
          logger.error(`  - Headers: ${JSON.stringify(error.request.headers)}`);
        }

        logger.error(`\nError stack trace: ${error.stack}`);
        reject(error);
      } else {
        logger.info('✓ PayPal API callback successful');
        logger.info(`Payment object received: ${JSON.stringify(payment, null, 2)}`);
        resolve(payment);
      }
    });
  });

  // Race between PayPal API call and timeout
  try {
    paypalPayment = await Promise.race([
      paypalPromise,
      createTimeoutPromise(10000),
    ]);
  } catch (error) {
    logger.error(`\n❌ PAYPAL API CALL FAILED: ${error.message}`);
    logger.error(`Error details: ${JSON.stringify(error, null, 2)}`);
    const errorMsg = error.message || 'Failed to create PayPal order';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  // ========== VALIDATE RESPONSE ==========
  logger.info('\n--- STEP 9: VALIDATE PAYPAL RESPONSE ---');
  logger.info(`Response type: ${typeof paypalPayment}`);
  logger.info(`Response keys: ${Object.keys(paypalPayment || {}).join(', ')}`);
  logger.info(`Full response object: ${JSON.stringify(paypalPayment, null, 2)}`);

  if (!paypalPayment) {
    logger.error('❌ PayPal response is null or undefined');
    const errorMsg = 'PayPal API returned empty response';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  const paymentId = paypalPayment.id;
  const paymentState = paypalPayment.state;
  const links = paypalPayment.links || [];
  const approvalLink = links.find(link => link.rel === 'approval_url');
  const approvalUrl = approvalLink ? approvalLink.href : null;

  logger.info(`\nExtracted from response:`);
  logger.info(`  - Payment ID: ${paymentId}`);
  logger.info(`  - Payment State: ${paymentState}`);
  logger.info(`  - Approval URL: ${approvalUrl}`);
  logger.info(`  - Links count: ${links.length}`);

  if (!paymentId) {
    logger.error('❌ PayPal response missing payment ID');
    logger.error(`Full response: ${JSON.stringify(paypalPayment)}`);
    const errorMsg = 'PayPal API response missing payment ID';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  if (!approvalUrl) {
    logger.error('❌ PayPal response missing approval URL');
    logger.error(`Full response: ${JSON.stringify(paypalPayment)}`);
    const errorMsg = 'PayPal API response missing approval URL';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  logger.info('✓ Response validation passed');

  // ========== VERIFY APPROVAL URL ENVIRONMENT ==========
  logger.info('\n--- STEP 10: VERIFY APPROVAL URL ENVIRONMENT ---');
  if (paypalMode === 'live') {
    if (approvalUrl.includes('api.paypal.com')) {
      logger.info('✓ Approval URL is using PayPal PRODUCTION environment (api.paypal.com)');
    } else if (approvalUrl.includes('sandbox.paypal.com')) {
      logger.error('❌ ERROR: Approval URL is using PayPal SANDBOX (sandbox.paypal.com) but mode is set to LIVE');
      logger.error('This indicates a configuration mismatch!');
    } else {
      logger.warn(`⚠️  Approval URL domain is unexpected: ${approvalUrl}`);
    }
  } else {
    if (approvalUrl.includes('sandbox.paypal.com')) {
      logger.info('✓ Approval URL is using PayPal SANDBOX environment (sandbox.paypal.com)');
    } else if (approvalUrl.includes('api.paypal.com')) {
      logger.error('❌ ERROR: Approval URL is using PayPal PRODUCTION (api.paypal.com) but mode is set to SANDBOX');
      logger.error('This indicates a configuration mismatch!');
    } else {
      logger.warn(`⚠️  Approval URL domain is unexpected: ${approvalUrl}`);
    }
  }

  // ========== BUILD RESPONSE ==========
  logger.info('\n--- STEP 11: BUILD RESPONSE ---');
  const responseData = {
    success: true,
    token: paymentId,
    approvalUrl: approvalUrl,
  };

  logger.info(`Response structure:`);
  logger.info(`  - success: ${responseData.success}`);
  logger.info(`  - token: ${responseData.token}`);
  logger.info(`  - approvalUrl: ${responseData.approvalUrl}`);
  logger.info(`  - Response is OBJECT (not array): ${typeof responseData === 'object' && !Array.isArray(responseData)}`);
  logger.info(`Full response: ${JSON.stringify(responseData, null, 2)}`);

  logger.info('\n--- STEP 12: SEND RESPONSE TO CLIENT ---');
  logger.info('Calling res.json() with response data...');
  res.json(responseData);
  logger.info('✓ res.json() called successfully');

  logger.info('\n✓✓✓ CREATE ORDER REQUEST COMPLETED SUCCESSFULLY');
  logger.info('========== REQUEST COMPLETE ==========\n');
});

// ============================================================================
// POST /paypal/execute-payment
// Executes a PayPal payment (captures the order)
// Request body: { paymentId, payerId }
// Response: { success: true, id: string, status: string, amount: string } or { success: false, error: string }
// ============================================================================

router.post('/execute-payment', async (req, res) => {
  logger.info('\n========== EXECUTE PAYMENT REQUEST ==========');
  logger.info(`Timestamp: ${new Date().toISOString()}`);
  logger.info(`Request method: ${req.method}`);
  logger.info(`Request path: ${req.path}`);
  logger.info(`PayPal Mode: ${paypalMode}`);

  // ========== LOG INCOMING REQUEST ==========
  logger.info('\n--- STEP 1: LOG INCOMING REQUEST BODY ---');
  logger.info(`Raw request body: ${JSON.stringify(req.body, null, 2)}`);

  const { paymentId, payerId } = req.body;

  logger.info('Extracted parameters:');
  logger.info(`  - paymentId: ${paymentId}`);
  logger.info(`  - payerId: ${payerId}`);

  // ========== VALIDATE REQUEST DATA ==========
  logger.info('\n--- STEP 2: VALIDATE REQUEST DATA ---');

  if (!paymentId || typeof paymentId !== 'string') {
    logger.warn(`❌ Validation failed: invalid payment ID: ${paymentId}`);
    return res.status(400).json({
      success: false,
      error: 'Valid payment ID is required',
      received: { paymentId },
    });
  }
  logger.info(`✓ Payment ID validation passed: ${paymentId}`);

  if (!payerId || typeof payerId !== 'string') {
    logger.warn(`❌ Validation failed: invalid payer ID: ${payerId}`);
    return res.status(400).json({
      success: false,
      error: 'Valid payer ID is required',
      received: { payerId },
    });
  }
  logger.info(`✓ Payer ID validation passed: ${payerId}`);

  logger.info('✓✓✓ All request data validations passed');

  // ========== CALL PAYPAL API TO EXECUTE PAYMENT WITH TIMEOUT ==========
  logger.info('\n--- STEP 3: CALL PAYPAL API TO EXECUTE PAYMENT ---');
  logger.info(`Using payment ID: ${paymentId}`);
  logger.info(`Using payer ID: ${payerId}`);
  if (paypalMode === 'live') {
    logger.warn('⚠️  PRODUCTION MODE: Calling PayPal LIVE API (api.paypal.com)');
  } else {
    logger.info('Calling PayPal SANDBOX API (sandbox.paypal.com)');
  }
  logger.info('Calling paypal.payment.execute() method with 10s timeout...');

  let executedPayment;
  const paypalPromise = new Promise((resolve, reject) => {
    logger.info('PayPal promise created, calling payment.execute()...');
    paypal.payment.execute(paymentId, { payer_id: payerId }, (error, payment) => {
      logger.info('PayPal callback invoked');
      if (error) {
        logger.error('\n❌ PAYPAL API CALLBACK ERROR');
        logger.error(`Error message: ${error.message}`);
        logger.error(`Error name: ${error.name}`);
        logger.error(`Full error object: ${JSON.stringify(error, null, 2)}`);
        reject(error);
      } else {
        logger.info('✓ PayPal API callback successful');
        logger.info(`Payment object received: ${JSON.stringify(payment, null, 2)}`);
        resolve(payment);
      }
    });
  });

  // Race between PayPal API call and timeout
  try {
    executedPayment = await Promise.race([
      paypalPromise,
      createTimeoutPromise(10000),
    ]);
  } catch (error) {
    logger.error(`\n❌ PAYPAL API CALL FAILED: ${error.message}`);
    logger.error(`Error details: ${JSON.stringify(error, null, 2)}`);
    const errorMsg = error.message || 'Failed to execute PayPal payment';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  // ========== VALIDATE RESPONSE ==========
  logger.info('\n--- STEP 4: VALIDATE PAYPAL RESPONSE ---');
  logger.info(`Response type: ${typeof executedPayment}`);
  logger.info(`Response keys: ${Object.keys(executedPayment || {}).join(', ')}`);
  logger.info(`Full response object: ${JSON.stringify(executedPayment, null, 2)}`);

  if (!executedPayment) {
    logger.error('❌ PayPal response is null or undefined');
    const errorMsg = 'PayPal API returned empty response';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  const paymentIdResponse = executedPayment.id;
  const paymentState = executedPayment.state;
  const transactions = executedPayment.transactions || [];
  const totalAmount = transactions.length > 0 ? transactions[0].amount.total : '0';

  logger.info(`\nExtracted from response:`);
  logger.info(`  - Payment ID: ${paymentIdResponse}`);
  logger.info(`  - Payment State: ${paymentState}`);
  logger.info(`  - Total Amount: ${totalAmount}`);
  logger.info(`  - Transactions: ${transactions.length}`);

  if (!paymentIdResponse) {
    logger.error('❌ PayPal response missing payment ID');
    logger.error(`Full response: ${JSON.stringify(executedPayment)}`);
    const errorMsg = 'PayPal API response missing payment ID';
    logger.error(`Returning error response: ${errorMsg}`);
    return res.status(500).json({ success: false, error: errorMsg });
  }

  logger.info('✓ Response validation passed');

  // ========== BUILD RESPONSE ==========
  logger.info('\n--- STEP 5: BUILD RESPONSE ---');
  const responseData = {
    success: true,
    id: paymentIdResponse,
    status: paymentState,
    amount: totalAmount,
  };

  logger.info(`Response structure:`);
  logger.info(`  - success: ${responseData.success}`);
  logger.info(`  - id: ${responseData.id}`);
  logger.info(`  - status: ${responseData.status}`);
  logger.info(`  - amount: ${responseData.amount}`);
  logger.info(`  - Response is OBJECT (not array): ${typeof responseData === 'object' && !Array.isArray(responseData)}`);
  logger.info(`Full response: ${JSON.stringify(responseData, null, 2)}`);

  logger.info('\n--- STEP 6: SEND RESPONSE TO CLIENT ---');
  logger.info('Calling res.json() with response data...');
  res.json(responseData);
  logger.info('✓ res.json() called successfully');

  logger.info('\n✓✓✓ EXECUTE PAYMENT REQUEST COMPLETED SUCCESSFULLY');
  logger.info('========== REQUEST COMPLETE ==========\n');
});

// ============================================================================
// POST /paypal/create-payment
// Creates a PayPal payment with customer data and shipping address
// Request body: { items, amount, currency, returnUrl, cancelUrl, customerData }
// Response: { approvalUrl: string }
// ============================================================================

router.post('/create-payment', (req, res, next) => {
  logger.info('\n========== CREATE PAYMENT (WITH CUSTOMER DATA) REQUEST ==========');
  
  const { items, amount, currency, returnUrl, cancelUrl, customerData } = req.body;

  // Validation without try/catch as requested (throws Error to be caught by errorMiddleware)
  if (!items || !Array.isArray(items) || items.length === 0) {
    throw new Error('Items array is required and cannot be empty');
  }

  if (!customerData) {
    throw new Error('Customer data is required');
  }

  // Format items and ensure description exists
  const formattedItems = items.map(item => {
    if (!item.name) throw new Error('Each item must have a name');
    if (item.price === undefined || item.price === null) throw new Error('Each item must have a price');
    if (!item.quantity) throw new Error('Each item must have a quantity');

    return {
      name: item.name,
      description: item.description || item.name, // Fallback to name if description is missing
      quantity: item.quantity.toString(),
      price: item.price.toString()
    };
  });

  const itemTotal = formattedItems.reduce((sum, item) => sum + (parseFloat(item.price) * parseInt(item.quantity)), 0);

  // Build PayPal payment object with shipping address
  const paypalPaymentData = {
    intent: 'sale',
    payer: {
      payment_method: 'paypal'
    },
    redirect_urls: {
      return_url: returnUrl,
      cancel_url: cancelUrl
    },
    transactions: [{
      amount: {
        total: amount.toString(),
        currency: (currency || 'BRL').toUpperCase(),
        details: {
          subtotal: itemTotal.toString(),
          tax: '0'
        }
      },
      description: 'Purchase from Velour Perfumes',
      item_list: {
        items: formattedItems,
        shipping_address: {
          recipient_name: customerData.fullName,
          line1: `${customerData.street}, ${customerData.number} ${customerData.complement || ''}`.trim(),
          city: customerData.city,
          state: customerData.state,
          postal_code: customerData.postalCode,
          country_code: customerData.country || 'BR'
        }
      }
    }]
  };

  logger.info('Calling paypal.payment.create() with customer data...');
  
  paypal.payment.create(paypalPaymentData, (error, payment) => {
    if (error) {
      logger.error('PayPal API Error:', error);
      return next(error);
    }
    
    const approvalUrl = payment.links?.find(link => link.rel === 'approval_url')?.href;
    
    if (!approvalUrl) {
      return next(new Error('Approval URL not found in PayPal response'));
    }
    
    logger.info('✓ Payment created successfully, returning approval URL');
    res.json({ approvalUrl });
  });
});

export default router;
