
import React, { useState, useEffect } from 'react';
import { Loader2, AlertCircle, Wallet } from 'lucide-react';
import apiServerClient from '@/lib/apiServerClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

const PayPalCheckout = ({ amount, items, disabled, checkoutData, onOpenModal, triggerPayment, onPaymentTriggered }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  // Auto-trigger payment when checkoutData is provided and triggerPayment is true
  useEffect(() => {
    if (triggerPayment && checkoutData && !isLoading) {
      handlePayment();
      if (onPaymentTriggered) onPaymentTriggered();
    }
  }, [triggerPayment, checkoutData]);

  const handlePayment = async () => {
    if (disabled || !items || items.length === 0) return;

    // If no customer data, open the modal first
    if (!checkoutData) {
      if (onOpenModal) onOpenModal();
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const paymentAmount = Number(amount.toFixed(2));
      
      const returnUrl = `${window.location.origin}/paypal-success?paymentId={PAYMENT_ID}&payerId={PAYER_ID}`;
      const cancelUrl = `${window.location.origin}/paypal-cancel`;

      // Format items to ensure they have the required fields for the backend
      const formattedItems = items.map(item => {
        const itemName = item.name || item.product?.title || 'Produto Velour';
        return {
          id: item.id || item.variant?.id || item.product?.id || 'unknown',
          name: itemName,
          // CRITICAL: PayPal requires description. Fallback to name if missing.
          description: item.description || itemName,
          price: parseFloat(item.price || (item.variant?.price_in_cents / 100) || item.product?.price || 0),
          quantity: item.quantity || 1
        };
      });

      console.log('[PayPalCheckout] Sending request with items and customer data:', { 
        itemsCount: formattedItems.length, 
        customer: checkoutData.email 
      });

      // Call the new create-payment endpoint
      const response = await apiServerClient.fetch('/paypal/create-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: paymentAmount,
          currency: 'BRL',
          items: formattedItems,
          customerData: checkoutData, // Include customer address data
          returnUrl,
          cancelUrl
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || 'Erro ao criar pedido do PayPal');
      }

      const data = await response.json();
      
      if (data.approvalUrl) {
        toast({
          title: 'Redirecionando...',
          description: 'Você está sendo levado ao ambiente seguro do PayPal.',
        });
        window.location.href = data.approvalUrl;
      } else {
        throw new Error('URL de aprovação não encontrada na resposta do servidor.');
      }
    } catch (err) {
      console.error('[PayPalCheckout] Erro:', err);
      setError(err.message);
      toast({
        variant: 'destructive',
        title: 'Erro ao iniciar pagamento',
        description: err.message
      });
      setIsLoading(false);
    }
  };

  if (disabled) {
    return (
      <div className="p-5 bg-zinc-900/80 border border-amber-900/30 rounded-xl text-center text-amber-100/60 text-sm shadow-inner">
        Preencha todos os dados necessários para liberar o pagamento com PayPal.
      </div>
    );
  }

  if (!items || items.length === 0) {
    return (
      <div className="p-5 bg-zinc-900/80 border border-amber-900/30 rounded-xl text-center text-amber-100/60 text-sm shadow-inner">
        Seu carrinho está vazio.
      </div>
    );
  }

  return (
    <div className="space-y-4 w-full mt-6">
      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-3 text-red-400 mb-4">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="flex-1 text-left">
            <p className="font-medium text-sm">Erro no Pagamento</p>
            <p className="text-xs opacity-80 mt-1">{error}</p>
          </div>
        </div>
      )}

      <Button
        onClick={handlePayment}
        disabled={isLoading || disabled}
        className="w-full h-14 bg-[#0070ba] hover:bg-[#005ea6] text-white font-medium text-lg rounded-xl transition-all duration-300 flex items-center justify-center gap-3 shadow-lg shadow-[#0070ba]/20"
      >
        {isLoading ? (
          <Loader2 className="w-6 h-6 animate-spin" />
        ) : (
          <Wallet className="w-6 h-6" />
        )}
        {isLoading ? 'Processando...' : (checkoutData ? 'Pagar com PayPal' : 'Preencher Dados e Pagar')}
      </Button>
      
      <p className="text-center text-xs text-amber-100/50 mt-3">
        Você será redirecionado para o ambiente seguro do PayPal para concluir a compra.
      </p>
    </div>
  );
};

export default PayPalCheckout;
