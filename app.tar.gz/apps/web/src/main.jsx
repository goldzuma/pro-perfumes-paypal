
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// HMR & WebSocket Logging for Debugging
if (import.meta.hot) {
  import.meta.hot.on('vite:beforeUpdate', () => {
    console.log('🔄 [HMR] Update incoming...');
  });
  
  import.meta.hot.on('vite:error', (err) => {
    console.error('❌ [HMR] Error:', err);
  });

  import.meta.hot.on('vite:ws:disconnect', () => {
    console.warn('⚠️ [WebSocket] Disconnected. Attempting to reconnect or reload...');
    // Fallback if WebSocket closes unexpectedly
    setTimeout(() => {
      if (document.visibilityState === 'visible') {
        console.log('🔄 [WebSocket] Forcing reload due to closed state');
        // window.location.reload(); // Uncomment if aggressive reload is needed
      }
    }, 5000);
  });
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
);
